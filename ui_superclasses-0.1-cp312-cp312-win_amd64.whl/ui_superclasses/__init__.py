from .lookup_window import LookupWindow
from .details_window import DetailsWindow
